# VTrack 2.0

* Added ATT (Animal Tracking Toolbox) collection of functions to VTrack. Includes the functions
* `abacusPlot()` function added to package
* `COA()` function added to package
* `detectionSummary()` function added to package
* `dispersalSummary()` function added to package
* `HRSummary()` function added to package
* `setupData()` function added to package



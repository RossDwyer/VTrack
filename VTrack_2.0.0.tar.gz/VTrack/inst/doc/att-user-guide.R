## ----echo=FALSE, out.width='100%'----------------------------------------
knitr::include_graphics('images/Fig1b.png')

## ----echo=FALSE, out.width='100%'----------------------------------------
knitr::include_graphics('images/Fig2.png')

## ---- include=TRUE, eval=FALSE-------------------------------------------
#  install.packages("VTrack")
#  
#  ## The development version can be also be accessed from GitHub:
#  install.packages("devtools")
#  devtools::install_github("rossdwyer/VTrack")

## ---- eval=TRUE, message=FALSE-------------------------------------------
library(VTrack)
#library(sp)

## ---- eval=TRUE, message=FALSE, warning=FALSE----------------------------
## Input example datasets
data(IMOSdata)  ## Detection data exported from IMOS data repository
data(VEMCOdata) ## Detection data exported from a VUE database
data(taginfo)
data(statinfo)

## Setup data for use with the Animal Tracking Toolbox
ATTdata <- setupData(Tag.Detections = IMOSdata, 
                     Tag.Metadata = taginfo, 
                     Station.Information = statinfo, 
                     source="IMOS",
                     tzone= "UTC")

## ---- eval=TRUE, message=FALSE, warning=FALSE----------------------------
## Calculate detecion metrics with monthly subsets chosen
detSum<-detectionSummary(ATTdata,  
                         sub = "%Y-%m")

## ---- eval=TRUE----------------------------------------------------------
head(detSum)

## ---- eval=FALSE---------------------------------------------------------
#  ## Accessing metrics of detection for full tag life
#  detSum$Overall
#  
#  ## Accessing metrics of detection for each temporal subset
#  detSum$Subsetted

## ---- eval=FALSE---------------------------------------------------------
#  abacusPlot(ATTdata)

## ----echo=FALSE, out.width='100%'----------------------------------------
knitr::include_graphics('images/Fig3.png')

## ---- eval=FALSE---------------------------------------------------------
#  ## Create a facetted abacus plot for individuals 77523274 and 77523147
#  abacusPlot(ATTdata,
#             id=c("77523274","77523147"),
#             facet=TRUE)

## ----echo=FALSE, out.width='100%'----------------------------------------
knitr::include_graphics('images/Fig4.png')

## ---- eval=FALSE---------------------------------------------------------
#  ## Calculate dispersal metrics
#  dispSum<-dispersalSummary(ATTdata)

## ---- echo=FALSE, results='hide', fig.keep='all', message = FALSE--------
## Calculate dispersal metrics
dispSum<-dispersalSummary(ATTdata)

## ---- eval=TRUE, message=FALSE, warning=FALSE----------------------------
## Accessing metrics of dispersal
dispSum

## ---- eval=TRUE, message=FALSE, warning=FALSE----------------------------
## First, estimate Short-term center of activities
COAdata<-COA(ATTdata, 
             timestep = 60, ## timestep bin used to estimate centers of activity (in minutes)
             split = TRUE)

## ---- eval=TRUE, message=FALSE, warning=FALSE----------------------------
COAdata[1:2]


## ---- eval=TRUE, message=FALSE, warning=FALSE----------------------------
COAdata$`77523307`


## ---- eval=FALSE, message=FALSE, warning=FALSE---------------------------
#  ## Define projected Coordinate Reference System
#  # projected coordinate systems should signify distance in meters so the output area values are in sq meters
#  # (here epsg:3577 refers to the GDA94 Australian Albers projection)
#  library(raster)
#  proj<-CRS("+init=epsg:3577")
#  
#  ## HRSummary() requires calculation of COAs first
#  ## Estimate 100% Maximum Convex Polygon (MCP) areas
#  mcp_est <- HRSummary(COAdata,
#                       projCRS=proj,
#                       type="MCP",
#                       cont=100,
#                       sub = "%Y-%m")

## ---- eval=FALSE, message=FALSE, warning=FALSE---------------------------
#  mcp_est
#  

## ---- eval=FALSE, message=FALSE, warning=FALSE---------------------------
#  ##*** Warning: the following might take a little while to run! ***##
#  ## Estimate 50% and 95% fixed Kernel Utilisation Distribution ('fKUD') contour areas with cumulative metrics calculated
#  fkud_est<-HRSummary(COAdata,
#                     projCRS=proj,
#                     type="fKUD",
#                     cont=c(50,95),
#                     cumulative=TRUE)

## ---- eval=FALSE, message=FALSE, warning=FALSE---------------------------
#  ## Estimate 20%, 50% and 95% Brownian Bridge Kernel Utilisation Distribution ('BBKUD') contour areas and store polygons
#  BBkud_est<-HRSummary(COAdata,
#                     projCRS=proj,
#                     type="BBKUD",
#                     cont=c(20,50,95),
#                     storepoly=TRUE)

## ---- eval=FALSE, message=FALSE, warning=FALSE---------------------------
#  summary(BBkud_est)

## ---- eval=FALSE---------------------------------------------------------
#  `BBkud_est`
#      |---> `$Overall`    : tibble data frame with activity space metrics for full tag life
#      |---> `$Subsetted`  : tibble data frame with activity space metrics for each temporal subset
#      |---> `$Spatial.Objects` : list object with as many components as unique Tag.IDs in the data
#                  |---> `51448633`
#                  |---> `77523307`
#                            |----> `$BBKUD_full` : a raster object with the BBKUD for the full tag life
#                            |----> `$BBKUD_sub`  : a raster stack object with the BBKUD for each temporal subset
#                                        |-----> `$X2013.05` : raster object for subset '2013-05' (May 2013)
#                                        |-----> `$X2013.06` : raster object for subset '2013-06' (June 2013)
#                                        |-----> `$X2013.07` : raster object for subset '2013-07' (July 2013)

## ---- eval=FALSE, message=FALSE, warning=FALSE---------------------------
#  ## Base plots using raster
#  # Activity space for full tag life
#  
#  library(raster)
#  library(viridis) ## access more color palettes!
#  
#  ## Select rasters of full KUDs for each individual into a single list
#  fullstack <-
#    unlist(BBkud_est$Spatial.Objects)[grep("*_full", names(unlist(BBkud_est$Spatial.Objects)))]
#  
#  names(fullstack) <-
#    unlist(lapply(strsplit(names(fullstack), "[.]"), `[[`, 1))
#  
#  ## Lets plot the overall BBKUD for Tag.ID `77523307`
#  fulltag <- fullstack$`77523307`
#  values(fulltag)[values(fulltag) > 96] <- NA
#  plot(fulltag, col = viridis(100), zlim = c(0, 100),
#       xlim=c(151.9, 152.1), ylim=c(-23.55, -23.4))
#  points(station_latitude ~ station_longitude, statinfo, col = 2, cex=0.7)
#  points(Latitude.coa ~ Longitude.coa,
#         data = COAdata$`77523307`,
#         pch = 20,
#         col = 4,
#         cex = 0.5)
#  contour(fulltag, add = TRUE, levels = c(50, 95))

## ----echo=FALSE, out.width='100%'----------------------------------------
knitr::include_graphics('images/Fig5.png')

## ---- eval=FALSE, message=FALSE, warning=FALSE---------------------------
#  # Monthly activity space for `77523307`
#  ## Select rasters of subsetted KUDs for each individual into a single list
#  substack <-
#    unlist(BBkud_est$Spatial.Objects)[grep("*_sub", names(unlist(BBkud_est$Spatial.Objects)))]
#  
#  tag_subset <-
#    disaggregate(substack$`77523307.BBKUD_sub`,
#    fact = 3,
#    method = 'bilinear')
#  
#  values(tag_subset)[values(tag_subset) > 96] <- NA
#  names(tag_subset) <-
#    format(ymd(paste0(substring(
#    names(tag_subset), 2
#    ), ".01")), "%B %Y")
#  
#  tag.det<-
#    COAdata$`77523307` %>%
#    mutate(sub = format(TimeStep.coa, "%B.%Y"))
#  
#  coa.dat<-
#    ungroup(tag.det) %>%
#    dplyr::select(Longitude.coa,Latitude.coa,sub) %>%
#    split(.$sub)
#  
#  ## Plot monthly KUD for tag `77523307`
#  library(rasterVis)
#  
#  rasterVis::levelplot(tag_subset,
#            names.attr = sub("[.]", " ", names(tag_subset)),
#            xlim=c(151.85, 152.15), ylim=c(-23.55, -23.4),
#            par.settings=viridisTheme,
#            panel = function(..., at, contour = FALSE){
#              panel.levelplot(..., at = at, contour = contour)
#              panel.contourplot(..., at = c(50, 95), contour = TRUE, lty=1, col.regions="transparent")
#              panel.points(coa.dat[[panel.number()]],
#                           pch = 20,
#                           cex = 0.2,
#                           col = 4)
#              }
#            )
#  

## ----echo=FALSE, out.width='100%'----------------------------------------
knitr::include_graphics('images/Fig6.png')

## ---- eval=FALSE, message=FALSE, warning=FALSE---------------------------
#  library(leaflet)
#  
#  ## Full KUD for all tagged animals
#  fullmap <- leaflet() %>%
#    addProviderTiles(providers$Esri.WorldImagery)
#  
#  for (i in 1:length(fullstack)) {
#    tempras<-disaggregate(fullstack[[i]], fact=3, method='bilinear')
#    values(tempras)[values(tempras) >95] <-NA
#    fullmap <-
#      fullmap %>%
#      addRasterImage(tempras, opacity = 0.5, group = names(fullstack)[i])
#  }
#  
#  coa.detections<-
#    do.call(rbind, COAdata) %>%
#    filter(Tag.ID %in% names(fullstack))
#  
#  fullmap <-
#    fullmap %>%
#    addCircleMarkers(lng = coa.detections$Longitude.coa, lat = coa.detections$Latitude.coa,
#                     color = "red", radius = 1, weight=1, group = coa.detections$Tag.ID) %>%
#    addCircleMarkers(lng = statinfo$station_longitude, lat = statinfo$station_latitude,
#                     fill = F, color = "white", radius = 4, weight = 2, group = "Receiver Stations") %>%
#    addMeasure(position = "bottomleft",
#               primaryLengthUnit = "meters",
#               primaryAreaUnit = "sqmeters") %>%
#    addLayersControl(
#      baseGroups = coa.detections$Tag.ID,
#      overlayGroups = "Receiver Stations",
#      options = layersControlOptions(collapsed = FALSE)
#    )
#  
#  fullmap

## ----echo=FALSE, out.width='100%'----------------------------------------
knitr::include_graphics('images/Fig7.png')

## ---- eval=FALSE, message=FALSE, warning=FALSE---------------------------
#  ## Monthly KUD for tag `77523307`
#  submap<-
#    leaflet() %>%
#    addProviderTiles(providers$Esri.WorldImagery)
#  
#  for (i in 1:length(names(tag_subset))) {
#    submap <-
#      submap %>%
#      addRasterImage(tag_subset[[i]], opacity = 0.5, group = gsub("[.]", " ", names(tag_subset)[i]))
#  }
#  
#  submap<-
#    submap %>%
#    addCircleMarkers(lng = tag.det$Longitude.coa, lat = tag.det$Latitude.coa,
#                     color = "red", radius = 1, weight=1, group = gsub("[.]", " ", tag.det$sub)) %>%
#    addCircleMarkers(lng = statinfo$station_longitude, lat = statinfo$station_latitude,
#                     fill = F, color = "white", radius = 4, weight=2, group = "Receiver Stations") %>%
#    addLayersControl(
#      baseGroups = gsub("[.]", " ", names(tag_subset)),
#      overlayGroups = "Receiver Stations",
#      options = layersControlOptions(collapsed = FALSE)
#    )
#  
#  submap
#  

## ----echo=FALSE, out.width='100%'----------------------------------------
knitr::include_graphics('images/Fig8.png')

## ---- eval=FALSE, message=FALSE, warning=FALSE---------------------------
#  ## ------------------------------------
#  ## Monthly breakdown of KUDs
#  ## Summary plots of KUDs over time
#  
#  library(plotly)
#  library(lubridate)
#  ## Interactive plotly
#  datly<-
#    BBkud_est$Subsetted %>%
#    filter(Tag.ID %in% names(fullstack)) %>%
#    mutate(Date = lubridate::ymd(paste0(subset,"-01")),
#           ActivitySpace_km2 = BBKUD.95/(10^6))
#  
#  p <- plot_ly(
#    type = 'scatter',
#    mode = "lines+markers",
#    x = filter(datly, Tag.ID %in% unique(datly$Tag.ID)[1])$Date,
#    y = filter(datly, Tag.ID %in% unique(datly$Tag.ID)[1])$ActivitySpace_km2,
#    name = unique(datly$Tag.ID)[1])
#  
#  for (id in unique(datly$Tag.ID)[-1]) {
#    p <- p %>%
#      add_trace(x = filter(datly, Tag.ID %in% id)$Date,
#                y = filter(datly, Tag.ID %in% id)$ActivitySpace_km2,
#                name = id, mode="lines+markers", visible = FALSE)}
#  
#  p <- p %>%
#    layout(
#      title = "Monthly extent of activity Space",
#      xaxis = list(title = "Date"),
#      yaxis = list(title = "Extent of Activity Space (km2)", rangemode = "tozero"),
#      updatemenus = list(
#        list(
#          type="dropdown",
#          y = 1,
#          ## Add all buttons at once
#          buttons = lapply(unique(datly$Tag.ID), FUN=function(id) {
#            list(method="restyle",
#                 args = list("visible", unique(datly$Tag.ID) == id),
#                 label = id)}))))
#  p

## ----echo=FALSE, out.width='100%'----------------------------------------
knitr::include_graphics('images/Fig9.png')

